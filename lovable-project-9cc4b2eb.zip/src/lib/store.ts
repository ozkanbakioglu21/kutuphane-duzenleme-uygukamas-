import { useSyncExternalStore } from "react";
import { norm } from "./tr";

export type Book = {
  id: string;
  firstName: string;
  lastName: string;
  title: string;
  publisher: string;
  genre: string;
  subgenre: string;
  subject: string;
  year?: number | undefined;
  pages?: number | undefined;
  cover?: string | undefined;
  shelf: string;
  note: string;
  read: boolean;
  readPages: number;
  createdAt: number;
};
export type UserList = { id: string; name: string; color: string; icon: string; bookIds: string[] };
export type Reminder = "none" | "notify" | "alarm";
export type Plan = {
  id: string;
  bookIds: string[];
  days: number[]; // 0 = Pazartesi … 6 = Pazar
  times: Record<number, string>;
  goalType: "minutes" | "pages";
  goalValue: number;
  startDate: string;
  endDate?: string | undefined;
  everyNWeeks: number;
  reminder: Reminder;
};
export type SessionStatus = "done" | "postponed" | "skipped";
export type Session = { id: string; planId: string; bookId: string; date: string; status: SessionStatus; progress: number };
export type Settings = {
  theme: "light" | "dark" | "system";
  fontScale: number;
  quietStart: string;
  quietEnd: string;
  remindersPaused: boolean;
  onboarded: boolean;
  view: "list" | "card";
};
export type State = {
  books: Book[];
  lists: UserList[];
  plans: Plan[];
  sessions: Session[];
  settings: Settings;
  recentSearches: string[];
  customSubgenres: Record<string, string[]>;
};

export const GENRES = ["Roman", "Hikâye", "Şiir", "Deneme", "Bilim", "Tarih", "Çocuk", "Felsefe"];
export const SUBGENRES: Record<string, string[]> = {
  Roman: ["Klasik", "Polisiye", "Bilimkurgu", "Fantastik", "Tarihî", "Distopya", "Aşk"],
  Hikâye: ["Kısa Öykü", "Modern Öykü", "Halk Hikâyesi"],
  Şiir: ["Modern Şiir", "Divan Şiiri", "Halk Şiiri"],
  Deneme: ["Edebî Deneme", "Kültür", "Gezi"],
  Bilim: ["Popüler Bilim", "Fizik", "Biyoloji", "Astronomi"],
  Tarih: ["Osmanlı", "Dünya Tarihi", "Biyografi"],
  Çocuk: ["Masal", "Resimli Kitap", "Gençlik"],
  Felsefe: ["Etik", "Varoluşçuluk", "Antik Felsefe"],
};

const KEY = "kutup:v1";
const defaults: State = {
  books: [],
  lists: [
    { id: "l-okunacak", name: "Okunacaklar", color: "oklch(0.55 0.12 250)", icon: "BookMarked", bookIds: [] },
    { id: "l-favori", name: "Favoriler", color: "oklch(0.6 0.18 25)", icon: "Heart", bookIds: [] },
  ],
  plans: [],
  sessions: [],
  settings: {
    theme: "system",
    fontScale: 1,
    quietStart: "23:00",
    quietEnd: "07:00",
    remindersPaused: false,
    onboarded: false,
    view: "card",
  },
  recentSearches: [],
  customSubgenres: {},
};

let state: State = defaults;
let hydrated = false;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

export function loadStore() {
  if (hydrated || typeof window === "undefined") return;
  hydrated = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw) as Partial<State>;
      state = { ...defaults, ...p, settings: { ...defaults.settings, ...p.settings } };
    }
  } catch {
    /* bozuk veri: varsayılanla devam */
  }
  emit();
}

export function setState(fn: (s: State) => State) {
  state = fn(state);
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    // Depolama doldu (büyük kapak fotoğrafları)
    import("sonner").then(({ toast }) => toast.error("Cihaz depolama alanı doldu. Bazı kapak fotoğraflarını silmeyi deneyin."));
  }
  emit();
}
export const getState = () => state;

export function useStore<T>(sel: (s: State) => T): T {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => sel(state),
    () => sel(defaults),
  );
}

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
export const authorName = (b: Book) => `${b.firstName} ${b.lastName}`.trim();

// ---------- Kitaplar ----------
export function isDuplicate(b: Omit<Book, "id" | "createdAt">, ignoreId?: string) {
  const k = (x: { firstName: string; lastName: string; title: string; publisher: string; year?: number | undefined }) =>
    [x.firstName, x.lastName, x.title, x.publisher, x.year ?? ""].map(norm).join("|");
  return state.books.some((x) => x.id !== ignoreId && k(x) === k(b));
}
export function saveBook(data: Omit<Book, "id" | "createdAt">, id?: string): string {
  const newId = id ?? uid();
  setState((s) => {
    const sub = data.subgenre.trim();
    const known = [...(SUBGENRES[data.genre] ?? []), ...(s.customSubgenres[data.genre] ?? [])];
    const customSubgenres =
      sub && data.genre && !known.some((k) => norm(k) === norm(sub))
        ? { ...s.customSubgenres, [data.genre]: [...(s.customSubgenres[data.genre] ?? []), sub] }
        : s.customSubgenres;
    const books = id
      ? s.books.map((b) => (b.id === id ? { ...b, ...data } : b))
      : [{ ...data, id: newId, createdAt: Date.now() }, ...s.books];
    return { ...s, books, customSubgenres };
  });
  return newId;
}
export function deleteBooks(ids: string[]) {
  const set = new Set(ids);
  setState((s) => ({
    ...s,
    books: s.books.filter((b) => !set.has(b.id)),
    lists: s.lists.map((l) => ({ ...l, bookIds: l.bookIds.filter((x) => !set.has(x)) })),
    plans: s.plans
      .map((p) => ({ ...p, bookIds: p.bookIds.filter((x) => !set.has(x)) }))
      .filter((p) => p.bookIds.length),
    sessions: s.sessions.filter((x) => !set.has(x.bookId)),
  }));
}

// ---------- Listeler ----------
export function toggleInList(listId: string, bookIds: string[], add: boolean) {
  setState((s) => ({
    ...s,
    lists: s.lists.map((l) =>
      l.id !== listId
        ? l
        : { ...l, bookIds: add ? [...l.bookIds, ...bookIds.filter((b) => !l.bookIds.includes(b))] : l.bookIds.filter((b) => !bookIds.includes(b)) },
    ),
  }));
}

// ---------- Çizelge ----------
export const DAYS = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];
export const ymd = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
export const dayIndex = (d: Date) => (d.getDay() + 6) % 7;
function mondayOf(d: Date) {
  const m = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  m.setDate(m.getDate() - dayIndex(m));
  return m;
}
export function planOccursOn(p: Plan, d: Date) {
  const key = ymd(d);
  if (key < p.startDate || (p.endDate && key > p.endDate)) return false;
  if (!p.days.includes(dayIndex(d))) return false;
  const [y = 2000, m = 1, dd = 1] = p.startDate.split("-").map(Number);
  const weeks = Math.round((mondayOf(d).getTime() - mondayOf(new Date(y, m - 1, dd)).getTime()) / (7 * 864e5));
  return weeks % Math.max(1, p.everyNWeeks) === 0;
}
export function occurrencesOn(s: State, d: Date) {
  return s.plans
    .filter((p) => planOccursOn(p, d))
    .map((p) => ({ plan: p, time: p.times[dayIndex(d)] ?? "20:00", session: s.sessions.find((x) => x.planId === p.id && x.date === ymd(d)) }))
    .sort((a, b) => a.time.localeCompare(b.time));
}
export function markSession(planId: string, bookId: string, date: string, status: SessionStatus, progress = 0) {
  setState((s) => {
    const prev = s.sessions.find((x) => x.planId === planId && x.date === date);
    const sessions = prev
      ? s.sessions.map((x) => (x === prev ? { ...x, status, progress, bookId } : x))
      : [...s.sessions, { id: uid(), planId, bookId, date, status, progress }];
    const plan = s.plans.find((p) => p.id === planId);
    const delta = status === "done" && plan?.goalType === "pages" ? progress - (prev?.status === "done" ? prev.progress : 0) : 0;
    const books = delta
      ? s.books.map((b) => {
          if (b.id !== bookId) return b;
          const readPages = Math.max(0, Math.min(b.pages ?? Infinity, b.readPages + delta));
          return { ...b, readPages, read: b.read || (!!b.pages && readPages >= b.pages) };
        })
      : s.books;
    return { ...s, sessions, books };
  });
}
export function streak(s: State, today = new Date()) {
  const done = new Set(s.sessions.filter((x) => x.status === "done").map((x) => x.date));
  const d = new Date(today);
  if (!done.has(ymd(d))) d.setDate(d.getDate() - 1);
  let n = 0;
  while (done.has(ymd(d))) {
    n++;
    d.setDate(d.getDate() - 1);
  }
  return n;
}

// ---------- Örnek veri ----------
export function loadSample() {
  const mk = (f: string, l: string, t: string, p: string, g: string, sg: string, su: string, y: number, pg: number): Book => ({
    id: uid(), firstName: f, lastName: l, title: t, publisher: p, genre: g, subgenre: sg, subject: su, year: y, pages: pg,
    shelf: "Salon rafı", note: "", read: false, readPages: 0, createdAt: Date.now() - Math.random() * 1e9,
  });
  const books = [
    mk("Lev", "Tolstoy", "Anna Karenina", "İş Bankası Kültür Yayınları", "Roman", "Klasik", "Aşk, toplum ve ahlak üzerine bir trajedi.", 2016, 960),
    mk("Lev", "Tolstoy", "Savaş ve Barış", "Can Yayınları", "Roman", "Tarihî", "Napolyon savaşları döneminde Rus aristokrasisi.", 2019, 1600),
    mk("Fyodor", "Dostoyevski", "Suç ve Ceza", "İş Bankası Kültür Yayınları", "Roman", "Klasik", "Bir öğrencinin işlediği cinayet ve vicdan.", 2015, 687),
    mk("Sabahattin", "Ali", "Kürk Mantolu Madonna", "Yapı Kredi Yayınları", "Roman", "Aşk", "Raif Efendi'nin Berlin'deki aşkı.", 2017, 160),
    mk("Orhan", "Veli", "Bütün Şiirleri", "Yapı Kredi Yayınları", "Şiir", "Modern Şiir", "Garip akımının öncü şiirleri.", 2014, 240),
    mk("Sait Faik", "Abasıyanık", "Semaver", "Yapı Kredi Yayınları", "Hikâye", "Modern Öykü", "İstanbul'un küçük insanları.", 2012, 120),
    mk("Carl", "Sagan", "Kozmos", "Altın Kitaplar", "Bilim", "Astronomi", "Evrenin ve insanlığın hikâyesi.", 2018, 432),
    mk("Halil", "İnalcık", "Osmanlı İmparatorluğu Klasik Çağ", "Yapı Kredi Yayınları", "Tarih", "Osmanlı", "1300–1600 arası Osmanlı tarihi.", 2003, 344),
    mk("Antoine de", "Saint-Exupéry", "Küçük Prens", "Can Yayınları", "Çocuk", "Masal", "Dostluk, sevgi ve büyümek üzerine.", 2020, 112),
    mk("Albert", "Camus", "Yabancı", "Can Yayınları", "Felsefe", "Varoluşçuluk", "Absürt ve yabancılaşma.", 2018, 111),
  ];
  setState((s) => ({ ...s, books: [...books, ...s.books] }));
}
export function resetAll() {
  setState(() => ({ ...defaults, settings: { ...defaults.settings, onboarded: true } }));
}
export function replaceState(next: State) {
  setState(() => ({ ...defaults, ...next, settings: { ...defaults.settings, ...next.settings } }));
}
