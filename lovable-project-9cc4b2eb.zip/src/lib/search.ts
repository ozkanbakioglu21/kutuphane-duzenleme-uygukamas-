import { norm } from "./tr";
import type { Book } from "./store";

export const FIELDS = [
  { key: "firstName", label: "Yazar Adı" },
  { key: "lastName", label: "Yazar Soyadı" },
  { key: "title", label: "Kitap Adı" },
  { key: "publisher", label: "Yayınevi" },
  { key: "genre", label: "Tür" },
  { key: "subgenre", label: "Alt Tür" },
  { key: "subject", label: "Konu" },
  { key: "year", label: "Basım Yılı" },
] as const;
export type FieldKey = (typeof FIELDS)[number]["key"];
export type Criterion = { field: FieldKey; value: string };

export function searchBooks(books: Book[], q: string, criteria: Criterion[] = []) {
  const nq = norm(q.trim());
  const active = criteria.filter((c) => c.value.trim());
  return books.filter((b) => {
    if (nq && !FIELDS.some((f) => norm(b[f.key]).includes(nq))) return false;
    return active.every((c) => norm(b[c.field]).includes(norm(c.value.trim())));
  });
}
