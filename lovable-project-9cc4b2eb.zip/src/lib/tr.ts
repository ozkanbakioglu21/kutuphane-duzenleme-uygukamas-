// Türkçe duyarlı metin yardımcıları
const MAP: Record<string, string> = { ç: "c", ğ: "g", ı: "i", ö: "o", ş: "s", ü: "u", â: "a", î: "i", û: "u" };

/** Tek karakteri arama için normalize eder (her zaman tek karakter döner, vurgulama için indeks korunur). */
function normChar(ch: string): string {
  const low = ch.toLocaleLowerCase("tr");
  const c = low[0] ?? "";
  if (MAP[c]) return MAP[c];
  const stripped = c.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  return stripped[0] ?? c;
}

export function norm(s: string | number | undefined | null): string {
  if (s === undefined || s === null) return "";
  return Array.from(String(s)).map(normChar).join("");
}

export const collator = new Intl.Collator("tr", { sensitivity: "base", numeric: true });
export const trCompare = (a: string, b: string) => collator.compare(a, b);

/** Eşleşen aralıkları (orijinal metin indeksleriyle) döndürür. */
export function matchRanges(text: string, query: string): [number, number][] {
  const q = norm(query.trim());
  if (!q) return [];
  const chars = Array.from(text);
  const n = chars.map(normChar).join("");
  const out: [number, number][] = [];
  let i = n.indexOf(q);
  while (i !== -1) {
    out.push([i, i + q.length]);
    i = n.indexOf(q, i + q.length);
  }
  return out;
}

function levenshtein(a: string, b: string) {
  const dp = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = dp[0]!;
    dp[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = dp[j]!;
      dp[j] = Math.min(dp[j]! + 1, dp[j - 1]! + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = tmp;
    }
  }
  return dp[b.length]!;
}

/** Yazım farkı olan benzer bir değeri bulur (birebir aynısı hariç). */
export function findSimilar(value: string, existing: string[]): string | null {
  const v = norm(value.trim()).replace(/\s+/g, " ");
  if (v.length < 3) return null;
  for (const e of existing) {
    if (e === value.trim()) continue;
    const n = norm(e).replace(/\s+/g, " ");
    if (n === v || (v.length > 5 && levenshtein(n, v) <= 2)) return e;
  }
  return null;
}
