import { describe, expect, it } from "vitest";
import { findSimilar, matchRanges, norm, trCompare } from "./tr";

describe("Türkçe arama", () => {
  it("ı/i ve I/İ farkını yok sayar", () => {
    expect(norm("IŞIK")).toBe(norm("ışık"));
    expect(norm("İstanbul")).toBe("istanbul");
    expect(norm("Iğdır")).toBe("igdir");
  });
  it("kısmi eşleşmeyi orijinal indekslerle bulur", () => {
    expect(matchRanges("Suç ve Ceza", "suc")).toEqual([[0, 3]]);
  });
  it("Türkçe alfabetik sıralar (ç, c'den sonra gelir)", () => {
    expect(["Çehov", "Dostoyevski", "Camus"].sort(trCompare)).toEqual(["Camus", "Çehov", "Dostoyevski"]);
  });
  it("yazım farklı yayınevini benzer bulur", () => {
    expect(findSimilar("can yayınlari", ["Can Yayınları"])).toBe("Can Yayınları");
  });
});
