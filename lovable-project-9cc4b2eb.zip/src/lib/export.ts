import { authorName, uid, type Book } from "./store";

const COLS: [keyof Book, string][] = [
  ["firstName", "Yazar Adı"], ["lastName", "Yazar Soyadı"], ["title", "Kitap Adı"], ["publisher", "Yayınevi"],
  ["genre", "Tür"], ["subgenre", "Alt Tür"], ["subject", "Konu"], ["year", "Basım Yılı"], ["pages", "Sayfa"],
  ["shelf", "Raf"], ["note", "Not"], ["read", "Okundu"],
];

export function download(name: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
const cell = (v: unknown) => (typeof v === "boolean" ? (v ? "Evet" : "Hayır") : v === undefined ? "" : String(v));
const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;

export function toCSV(books: Book[]) {
  return "\uFEFF" + [COLS.map((c) => esc(c[1])).join(";"), ...books.map((b) => COLS.map((c) => esc(cell(b[c[0]]))).join(";"))].join("\r\n");
}
export function toXLS(books: Book[]) {
  const h = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;");
  return `<html><head><meta charset="utf-8"></head><body><table><tr>${COLS.map((c) => `<th>${c[1]}</th>`).join("")}</tr>${books
    .map((b) => `<tr>${COLS.map((c) => `<td>${h(cell(b[c[0]]))}</td>`).join("")}</tr>`)
    .join("")}</table></body></html>`;
}

function parseCSV(text: string): string[][] {
  text = text.replace(/^\uFEFF/, "");
  const first = text.split("\n")[0] ?? "";
  const sep = (first.match(/;/g)?.length ?? 0) >= (first.match(/,/g)?.length ?? 0) ? ";" : ",";
  const rows: string[][] = [];
  let row: string[] = [], cur = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"' && text[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c;
    } else if (c === '"') q = true;
    else if (c === sep) { row.push(cur); cur = ""; }
    else if (c === "\n") { row.push(cur.replace(/\r$/, "")); rows.push(row); row = []; cur = ""; }
    else cur += c;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  return rows.filter((r) => r.some((x) => x.trim()));
}
export function fromCSV(text: string): Book[] {
  const [head, ...rows] = parseCSV(text);
  if (!head) return [];
  const idx = COLS.map(([, label]) => head.findIndex((h) => h.trim().toLocaleLowerCase("tr") === label.toLocaleLowerCase("tr")));
  return rows
    .map((r) => {
      const g = (i: number) => ((idx[i] ?? -1) >= 0 ? (r[idx[i]!] ?? "").trim() : "");
      const num = (s: string) => (s && /^\d+$/.test(s) ? Number(s) : undefined);
      return {
        id: uid(), firstName: g(0), lastName: g(1), title: g(2), publisher: g(3), genre: g(4), subgenre: g(5), subject: g(6),
        year: num(g(7)), pages: num(g(8)), shelf: g(9), note: g(10), read: /^(evet|true|1)$/i.test(g(11)), readPages: 0, createdAt: Date.now(),
      } as Book;
    })
    .filter((b) => b.title && b.lastName);
}

export function listText(name: string, books: Book[]) {
  return `${name}\n\n${books.map((b, i) => `${i + 1}. ${b.title} – ${authorName(b)}${b.publisher ? ` (${b.publisher}${b.year ? `, ${b.year}` : ""})` : ""}`).join("\n")}\n\nKÜTÜP ile paylaşıldı.`;
}
export function printPDF(name: string, books: Book[]) {
  const w = window.open("", "_blank");
  if (!w) return;
  const h = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;");
  w.document.write(`<html lang="tr"><head><meta charset="utf-8"><title>${h(name)}</title><style>body{font-family:Georgia,serif;padding:32px}h1{border-bottom:3px solid #b8892b}td,th{padding:6px 10px;border-bottom:1px solid #ddd;text-align:left}</style></head><body><h1>${h(name)}</h1><table><tr><th>#</th><th>Kitap</th><th>Yazar</th><th>Yayınevi</th><th>Yıl</th></tr>${books
    .map((b, i) => `<tr><td>${i + 1}</td><td>${h(b.title)}</td><td>${h(authorName(b))}</td><td>${h(b.publisher)}</td><td>${b.year ?? ""}</td></tr>`)
    .join("")}</table><p style="color:#888">KÜTÜP</p><script>setTimeout(()=>print(),300)</script></body></html>`);
  w.document.close();
}
