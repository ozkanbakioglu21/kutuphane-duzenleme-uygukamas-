import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, CalendarPlus, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Cover, Empty, openBookForm } from "@/components/kutup/ui-bits";
import { authorName, deleteBooks, saveBook, toggleInList, useStore } from "@/lib/store";

export const Route = createFileRoute("/kitap/$id")({
  head: () => ({
    meta: [
      { title: "Kitap Detayı – KÜTÜP" },
      { name: "description", content: "Kitap bilgileri, listeler ve okuma ilerlemesi." },
      { property: "og:title", content: "Kitap Detayı – KÜTÜP" },
      { property: "og:description", content: "Kitap bilgileri, listeler ve okuma ilerlemesi." },
    ],
  }),
  component: Detail,
});

function Detail() {
  const { id } = Route.useParams();
  const book = useStore((s) => s.books.find((b) => b.id === id));
  const lists = useStore((s) => s.lists);
  const [del, setDel] = useState(false);
  const nav = useNavigate();
  if (!book) return <Empty title="Kitap bulunamadı" text="Bu kitap silinmiş olabilir." action={<Link to="/kitaplar" className="text-primary underline">Kitaplarıma dön</Link>} />;
  const pct = book.pages ? Math.round((book.readPages / book.pages) * 100) : 0;
  const rows: [string, string | number | undefined][] = [
    ["Yayınevi", book.publisher], ["Tür", book.genre], ["Alt tür", book.subgenre], ["Basım yılı", book.year],
    ["Sayfa", book.pages], ["Raf / Konum", book.shelf], ["Kişisel not", book.note],
  ];
  return (
    <div className="pb-6">
      <div className="flex items-center justify-between p-2">
        <Button variant="ghost" size="icon" aria-label="Geri" onClick={() => history.back()}><ArrowLeft /></Button>
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" aria-label="Düzenle" onClick={() => openBookForm(book.id)}><Pencil /></Button>
          <Button variant="ghost" size="icon" aria-label="Sil" onClick={() => setDel(true)}><Trash2 /></Button>
        </div>
      </div>
      <div className="flex gap-4 px-4">
        <Cover book={book} className="h-44 w-30 w-[7.5rem] shrink-0 shadow-md" />
        <div className="min-w-0">
          <h1 className="text-2xl font-bold leading-tight">{book.title}</h1>
          <p className="mt-1 text-lg text-muted-foreground">{authorName(book)}</p>
          <div className="mt-3 flex items-center gap-2"><Switch checked={book.read} onCheckedChange={(v) => saveBook({ ...book, read: v }, book.id)} /><span className="text-sm">Okundu</span></div>
        </div>
      </div>
      {book.pages ? (
        <div className="mx-4 mt-4 rounded-xl border bg-card p-3">
          <div className="mb-2 flex justify-between text-sm"><span>İlerleme</span><span>{book.readPages} / {book.pages} sayfa (%{pct})</span></div>
          <Progress value={pct} />
        </div>
      ) : null}
      {book.subject && <p className="mx-4 mt-4 whitespace-pre-wrap rounded-xl bg-secondary p-4 text-sm">{book.subject}</p>}
      <dl className="mx-4 mt-4 divide-y rounded-xl border bg-card">
        {rows.filter(([, v]) => v).map(([k, v]) => (
          <div key={k} className="flex justify-between gap-4 p-3 text-sm"><dt className="text-muted-foreground">{k}</dt><dd className="text-right font-medium">{v}</dd></div>
        ))}
      </dl>
      <section className="mx-4 mt-4">
        <h2 className="mb-2 text-lg font-bold">Listelerim</h2>
        <div className="divide-y rounded-xl border bg-card">
          {lists.map((l) => (
            <label key={l.id} className="flex min-h-12 items-center gap-3 px-3">
              <Checkbox checked={l.bookIds.includes(book.id)} onCheckedChange={(v) => toggleInList(l.id, [book.id], !!v)} />
              <span className="h-3 w-3 rounded-full" style={{ background: l.color }} />{l.name}
            </label>
          ))}
        </div>
      </section>
      <div className="mx-4 mt-4">
        <Button className="h-12 w-full" variant="secondary" onClick={() => nav({ to: "/cizelge", search: { book: book.id } })}><CalendarPlus className="mr-2 h-5 w-5" /> Okuma planına ekle</Button>
      </div>
      <AlertDialog open={del} onOpenChange={setDel}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>“{book.title}” silinsin mi?</AlertDialogTitle><AlertDialogDescription>Bu işlem geri alınamaz.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Vazgeç</AlertDialogCancel><AlertDialogAction className="bg-destructive text-destructive-foreground" onClick={() => { deleteBooks([book.id]); toast.success("Kitap silindi."); nav({ to: "/kitaplar", search: {} }); }}>Sil</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
