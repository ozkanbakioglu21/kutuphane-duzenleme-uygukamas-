import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { BookPlus, Flame, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BookRow, Empty, Logo, openBookForm } from "@/components/kutup/ui-bits";
import { loadSample, occurrencesOn, streak, useStore } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "KÜTÜP – Ana Sayfa" },
      { name: "description", content: "Kütüphanenizin özeti, bugünün okuma planı ve son eklenen kitaplar." },
      { property: "og:title", content: "KÜTÜP – Kütüphane Düzenleme Uygulaması" },
      { property: "og:description", content: "Kitaplarınızı kataloglayın, arayın ve okuma planı yapın." },
    ],
  }),
  component: Home,
});

function Home() {
  const books = useStore((s) => s.books);
  const state = useStore((s) => s);
  const [q, setQ] = useState("");
  const nav = useNavigate();
  const today = occurrencesOn(state, new Date());
  const recent = [...books].sort((a, b) => b.createdAt - a.createdAt).slice(0, 5);

  return (
    <div>
      <section className="rounded-b-3xl px-5 pb-6 pt-8 text-primary-foreground" style={{ background: "var(--gradient-hero)" }}>
        <Logo className="text-3xl" />
        <p className="mt-2 text-sm opacity-80">Kütüphane Düzenleme Uygulaması</p>
        <div className="mt-5 grid grid-cols-3 gap-2 text-center">
          <Stat n={books.length} label="Kitap" />
          <Stat n={books.filter((b) => b.read).length} label="Okundu" />
          <Stat n={streak(state)} label="Gün seri" icon />
        </div>
        <form className="relative mt-5" onSubmit={(e) => { e.preventDefault(); nav({ to: "/kitaplar", search: { q } }); }}>
          <Search className="absolute left-3 top-3.5 h-5 w-5 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Yazar, kitap, yayınevi, tür ara…" className="h-12 bg-card pl-10 text-foreground" />
        </form>
      </section>

      <div className="space-y-6 p-4">
        <Button className="h-14 w-full text-base" onClick={() => openBookForm()}><BookPlus className="mr-2 h-5 w-5" /> Kitap Ekle</Button>

        <section>
          <div className="mb-2 flex items-center justify-between"><h2 className="text-xl font-bold">Bugünün planı</h2><Link to="/cizelge" className="text-sm text-primary">Çizelge</Link></div>
          {today.length === 0 ? (
            <p className="rounded-xl border bg-card p-4 text-sm text-muted-foreground">Bugün için planlanmış okuma yok.</p>
          ) : (
            <ul className="space-y-2">
              {today.map((o) => {
                const b = books.find((x) => x.id === o.plan.bookIds[0]);
                return (
                  <li key={o.plan.id} className="flex items-center justify-between rounded-xl border bg-card p-3">
                    <div><div className="font-semibold">{b?.title}</div><div className="text-sm text-muted-foreground">{o.time} · {o.plan.goalValue} {o.plan.goalType === "minutes" ? "dk" : "sayfa"}</div></div>
                    <span className="text-sm">{o.session ? { done: "✓ Tamamlandı", postponed: "Ertelendi", skipped: "Atlandı" }[o.session.status] : "Bekliyor"}</span>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <section>
          <div className="mb-2 flex items-center justify-between"><h2 className="text-xl font-bold">Son eklenenler</h2><Link to="/kitaplar" className="text-sm text-primary">Tümü</Link></div>
          {recent.length === 0 ? (
            <Empty title="Kütüphanen boş" text="İlk kitabını ekle ya da örnek verilerle uygulamayı keşfet." action={<Button variant="secondary" onClick={loadSample}>Örnek verileri yükle</Button>} />
          ) : (
            <ul className="divide-y rounded-xl border bg-card">
              {recent.map((b) => (
                <li key={b.id}><Link to="/kitap/$id" params={{ id: b.id }} className="block p-3"><BookRow book={b} /></Link></li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}

function Stat({ n, label, icon }: { n: number; label: string; icon?: boolean }) {
  return (
    <div className="rounded-xl bg-primary-foreground/10 p-3">
      <div className="flex items-center justify-center gap-1 font-display text-2xl font-bold">{icon && <Flame className="h-5 w-5 text-gold" />}{n}</div>
      <div className="text-xs opacity-80">{label}</div>
    </div>
  );
}
