import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Check, ChevronLeft, ChevronRight, Clock, Flame, Pencil, Plus, SkipForward, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Empty, PageHeader } from "@/components/kutup/ui-bits";
import { DAYS, dayIndex, markSession, occurrencesOn, setState, streak, uid, useStore, ymd, type Plan, type SessionStatus } from "@/lib/store";
import { trCompare } from "@/lib/tr";

export const Route = createFileRoute("/cizelge")({
  validateSearch: (s: Record<string, unknown>) => ({ book: typeof s['book'] === "string" ? (s['book'] as string) : undefined }) as { book?: string | undefined },
  head: () => ({
    meta: [
      { title: "Okuma Çizelgesi – KÜTÜP" },
      { name: "description", content: "Haftalık okuma planı, hedefler, seri ve istatistikler." },
      { property: "og:title", content: "Okuma Çizelgesi – KÜTÜP" },
      { property: "og:description", content: "Haftalık okuma planı, hedefler, seri ve istatistikler." },
    ],
  }),
  component: Schedule,
});

const STATUS: Record<SessionStatus, string> = { done: "Tamamlandı", postponed: "Ertelendi", skipped: "Atlandı" };

function Schedule() {
  const { book: preBook } = Route.useSearch();
  const state = useStore((s) => s);
  const [offset, setOffset] = useState(0);
  const [editing, setEditing] = useState<Plan | null>(null);
  const [mark, setMark] = useState<{ plan: Plan; date: string } | null>(null);
  const [today, setToday] = useState<Date | null>(null);
  useEffect(() => setToday(new Date()), []);
  const newPlan = (bookIds: string[] = []): Plan => ({
    id: "", bookIds, days: [dayIndex(new Date())], times: {}, goalType: "minutes", goalValue: 30,
    startDate: ymd(new Date()), everyNWeeks: 1, reminder: "notify",
  });
  useEffect(() => { if (preBook) setEditing(newPlan([preBook])); }, [preBook]); // eslint-disable-line

  const week = useMemo(() => {
    if (!today) return [];
    const m = new Date(today); m.setDate(m.getDate() - dayIndex(m) + offset * 7);
    return Array.from({ length: 7 }, (_, i) => { const d = new Date(m); d.setDate(m.getDate() + i); return d; });
  }, [today, offset]);

  const weekStats = useMemo(() => {
    const keys = new Set(week.map(ymd));
    let planned = 0;
    week.forEach((d) => (planned += occurrencesOn(state, d).length));
    const ss = state.sessions.filter((x) => keys.has(x.date));
    const done = ss.filter((x) => x.status === "done");
    const pages = done.reduce((a, x) => a + (state.plans.find((p) => p.id === x.planId)?.goalType === "pages" ? x.progress : 0), 0);
    const mins = done.reduce((a, x) => a + (state.plans.find((p) => p.id === x.planId)?.goalType === "minutes" ? x.progress : 0), 0);
    return { planned, done: done.length, pages, mins };
  }, [state, week]);

  const bookTitle = (id: string) => state.books.find((b) => b.id === id)?.title ?? "Silinmiş kitap";

  return (
    <div>
      <PageHeader title="Okuma Çizelgesi">
        <Button size="icon" aria-label="Yeni plan" onClick={() => setEditing(newPlan())} disabled={!state.books.length}><Plus /></Button>
      </PageHeader>
      <div className="space-y-5 p-4">
        <div className="grid grid-cols-4 gap-2 text-center">
          <StatBox v={<span className="inline-flex items-center gap-1"><Flame className="h-4 w-4 text-gold" />{streak(state)}</span>} l="gün seri" />
          <StatBox v={`${weekStats.done}/${weekStats.planned}`} l="oturum" />
          <StatBox v={weekStats.pages} l="sayfa" />
          <StatBox v={weekStats.mins} l="dakika" />
        </div>

        <section>
          <div className="mb-2 flex items-center justify-between">
            <Button size="icon" variant="ghost" aria-label="Önceki hafta" onClick={() => setOffset(offset - 1)}><ChevronLeft /></Button>
            <h2 className="text-lg font-bold">{offset === 0 ? "Bu hafta" : week[0]?.toLocaleDateString("tr-TR", { day: "numeric", month: "long" })}</h2>
            <Button size="icon" variant="ghost" aria-label="Sonraki hafta" onClick={() => setOffset(offset + 1)}><ChevronRight /></Button>
          </div>
          <ul className="space-y-2">
            {week.map((d) => {
              const occ = occurrencesOn(state, d);
              const isToday = today && ymd(d) === ymd(today);
              return (
                <li key={ymd(d)} className={`rounded-xl border bg-card p-3 ${isToday ? "border-primary ring-1 ring-primary" : ""}`}>
                  <div className="mb-1 text-sm font-semibold">{d.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "short" })}{isToday && " · Bugün"}</div>
                  {occ.length === 0 ? <p className="text-sm text-muted-foreground">Plan yok</p> : occ.map((o) => (
                    <button key={o.plan.id} className="flex min-h-11 w-full items-center justify-between gap-2 rounded-lg px-2 text-left hover:bg-muted" onClick={() => setMark({ plan: o.plan, date: ymd(d) })}>
                      <span className="flex items-center gap-2 text-sm"><Clock className="h-4 w-4 text-muted-foreground" />{o.time} · {bookTitle(o.plan.bookIds[0] ?? "")}{o.plan.bookIds.length > 1 && ` +${o.plan.bookIds.length - 1}`}</span>
                      <span className={`rounded-full px-2 py-0.5 text-xs ${o.session?.status === "done" ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{o.session ? STATUS[o.session.status] : `${o.plan.goalValue} ${o.plan.goalType === "minutes" ? "dk" : "sf"}`}</span>
                    </button>
                  ))}
                </li>
              );
            })}
          </ul>
        </section>

        <section>
          <h2 className="mb-2 text-lg font-bold">Aktif hedefler</h2>
          {state.plans.length === 0 ? (
            <Empty title="Henüz okuma planı yok" text={state.books.length ? "Hangi kitabı hangi gün ve saatte okuyacağını planla." : "Plan yapmak için önce kütüphanene kitap ekle."} action={state.books.length ? <Button onClick={() => setEditing(newPlan())}>Plan oluştur</Button> : undefined} />
          ) : (
            <ul className="space-y-2">
              {state.plans.map((p) => (
                <li key={p.id} className="rounded-xl border bg-card p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-semibold">{p.bookIds.map(bookTitle).join(", ")}</div>
                      <div className="text-sm text-muted-foreground">{p.days.sort().map((d) => `${DAYS[d]} ${p.times[d] ?? "20:00"}`).join(" · ")}</div>
                      <div className="text-xs text-muted-foreground">Hedef: {p.goalValue} {p.goalType === "minutes" ? "dakika" : "sayfa"} · {p.everyNWeeks === 1 ? "Her hafta" : `${p.everyNWeeks} haftada bir`} · {{ none: "Hatırlatma yok", notify: "Web bildirimi", alarm: "Sesli alarm" }[p.reminder]}</div>
                    </div>
                    <div className="flex">
                      <Button size="icon" variant="ghost" aria-label="Düzenle" onClick={() => setEditing(p)}><Pencil /></Button>
                      <Button size="icon" variant="ghost" aria-label="Sil" onClick={() => { if (confirm("Bu plan silinsin mi?")) setState((s) => ({ ...s, plans: s.plans.filter((x) => x.id !== p.id) })); }}><Trash2 /></Button>
                    </div>
                  </div>
                  {p.bookIds.map((id) => { const b = state.books.find((x) => x.id === id); if (!b?.pages) return null; const pct = Math.round((b.readPages / b.pages) * 100); return (
                    <div key={id} className="mt-2"><div className="flex justify-between text-xs"><span>{b.title}</span><span>{b.readPages}/{b.pages} sf</span></div><Progress value={pct} className="h-2" /></div>
                  ); })}
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
      <PlanEditor plan={editing} onClose={() => setEditing(null)} />
      <MarkDialog target={mark} onClose={() => setMark(null)} />
    </div>
  );
}

function StatBox({ v, l }: { v: React.ReactNode; l: string }) {
  return <div className="rounded-xl border bg-card p-2"><div className="font-display text-xl font-bold">{v}</div><div className="text-xs text-muted-foreground">{l}</div></div>;
}

function PlanEditor({ plan, onClose }: { plan: Plan | null; onClose: () => void }) {
  const books = useStore((s) => s.books);
  const [p, setP] = useState<Plan | null>(plan);
  useEffect(() => setP(plan), [plan]);
  if (!p) return <Sheet open={false} />;
  const sorted = [...books].sort((a, b) => trCompare(a.title, b.title));
  const toggleDay = (d: number) => setP({ ...p, days: p.days.includes(d) ? p.days.filter((x) => x !== d) : [...p.days, d] });
  const save = (): void => {
    if (!p.bookIds.length) { toast.error("En az bir kitap seçin."); return; }
    if (!p.days.length) { toast.error("En az bir gün seçin."); return; }
    if (!(p.goalValue > 0)) { toast.error("Hedef sıfırdan büyük olmalı."); return; }
    if (p.endDate && p.endDate < p.startDate) { toast.error("Bitiş tarihi başlangıçtan önce olamaz."); return; }
    if (p.reminder !== "none" && typeof Notification !== "undefined" && Notification.permission === "default") Notification.requestPermission();
    setState((s) => ({ ...s, plans: p.id ? s.plans.map((x) => (x.id === p.id ? p : x)) : [...s.plans, { ...p, id: uid() }] }));
    toast.success("Okuma planı kaydedildi.");
    onClose();
  };
  return (
    <Sheet open onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="bottom" className="mx-auto h-[92dvh] max-w-2xl overflow-y-auto rounded-t-2xl">
        <SheetHeader><SheetTitle className="font-display text-2xl">{p.id ? "Planı düzenle" : "Yeni okuma planı"}</SheetTitle></SheetHeader>
        <div className="space-y-5 px-4 pb-8">
          <div>
            <Label>Kitaplar</Label>
            <div className="mt-2 max-h-48 divide-y overflow-y-auto rounded-lg border">
              {sorted.map((b) => (
                <label key={b.id} className="flex min-h-11 items-center gap-3 px-3 text-sm">
                  <Checkbox checked={p.bookIds.includes(b.id)} onCheckedChange={(v) => setP({ ...p, bookIds: v ? [...p.bookIds, b.id] : p.bookIds.filter((x) => x !== b.id) })} />
                  <span className="truncate">{b.title} <span className="text-muted-foreground">– {b.lastName}</span></span>
                </label>
              ))}
            </div>
          </div>
          <div>
            <Label>Günler ve saatler</Label>
            <div className="mt-2 grid grid-cols-7 gap-1">
              {DAYS.map((d, i) => <button key={d} onClick={() => toggleDay(i)} className={`h-11 rounded-lg text-sm font-semibold ${p.days.includes(i) ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{d}</button>)}
            </div>
            <div className="mt-2 space-y-2">
              {[...p.days].sort().map((d) => (
                <div key={d} className="flex items-center gap-3"><span className="w-10 text-sm">{DAYS[d]}</span><Input type="time" value={p.times[d] ?? "20:00"} onChange={(e) => setP({ ...p, times: { ...p.times, [d]: e.target.value } })} /></div>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Hedef türü</Label>
              <Select value={p.goalType} onValueChange={(v) => setP({ ...p, goalType: v as Plan["goalType"] })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="minutes">Süre (dakika)</SelectItem><SelectItem value="pages">Sayfa</SelectItem></SelectContent></Select>
            </div>
            <div><Label>Hedef</Label><Input className="mt-1" inputMode="numeric" value={p.goalValue || ""} onChange={(e) => setP({ ...p, goalValue: Number(e.target.value.replace(/\D/g, "")) })} /></div>
            <div><Label>Başlangıç</Label><Input className="mt-1" type="date" value={p.startDate} onChange={(e) => setP({ ...p, startDate: e.target.value })} /></div>
            <div><Label>Bitiş (isteğe bağlı)</Label><Input className="mt-1" type="date" value={p.endDate ?? ""} onChange={(e) => setP({ ...p, endDate: e.target.value || undefined })} /></div>
            <div><Label>Tekrar</Label>
              <Select value={String(p.everyNWeeks)} onValueChange={(v) => setP({ ...p, everyNWeeks: Number(v) })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="1">Her hafta</SelectItem><SelectItem value="2">2 haftada bir</SelectItem><SelectItem value="3">3 haftada bir</SelectItem><SelectItem value="4">4 haftada bir</SelectItem></SelectContent></Select>
            </div>
            <div><Label>Hatırlatma</Label>
              <Select value={p.reminder} onValueChange={(v) => setP({ ...p, reminder: v as Plan["reminder"] })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">Hatırlatma yok</SelectItem><SelectItem value="notify">Web Bildirimi</SelectItem><SelectItem value="alarm">Sesli Alarm</SelectItem></SelectContent></Select>
            </div>
          </div>
          <Button className="h-12 w-full" onClick={save}>Planı kaydet</Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function MarkDialog({ target, onClose }: { target: { plan: Plan; date: string } | null; onClose: () => void }) {
  const books = useStore((s) => s.books);
  const sessions = useStore((s) => s.sessions);
  const [bookId, setBookId] = useState("");
  const [progress, setProgress] = useState("");
  useEffect(() => {
    if (!target) return undefined;
    const prev = sessions.find((x) => x.planId === target.plan.id && x.date === target.date);
    setBookId(prev?.bookId ?? target.plan.bookIds[0] ?? "");
    setProgress(String(prev?.progress || target.plan.goalValue));
  }, [target]);
  if (!target) return null;
  const set = (st: SessionStatus) => {
    markSession(target.plan.id, bookId, target.date, st, st === "done" ? Number(progress) || 0 : 0);
    toast.success(`Oturum: ${STATUS[st]}`);
    onClose();
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Okuma oturumu</DialogTitle></DialogHeader>
        <div className="space-y-3">
          {target.plan.bookIds.length > 1 && (
            <Select value={bookId} onValueChange={setBookId}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{target.plan.bookIds.map((id) => <SelectItem key={id} value={id}>{books.find((b) => b.id === id)?.title}</SelectItem>)}</SelectContent></Select>
          )}
          <Label>{target.plan.goalType === "pages" ? "Okunan sayfa" : "Okunan süre (dk)"}</Label>
          <Input inputMode="numeric" value={progress} onChange={(e) => setProgress(e.target.value.replace(/\D/g, ""))} />
        </div>
        <DialogFooter className="grid grid-cols-3 gap-2 sm:flex">
          <Button onClick={() => set("done")}><Check className="mr-1 h-4 w-4" />Tamamlandı</Button>
          <Button variant="secondary" onClick={() => set("postponed")}><Clock className="mr-1 h-4 w-4" />Ertelendi</Button>
          <Button variant="outline" onClick={() => set("skipped")}><SkipForward className="mr-1 h-4 w-4" />Atlandı</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
