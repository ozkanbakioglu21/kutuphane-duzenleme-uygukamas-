import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { CheckSquare, Grid2x2, List, Plus, Search, SlidersHorizontal, Trash2, X, ListPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { BookRow, Cover, Empty, Hl, PageHeader, openBookForm } from "@/components/kutup/ui-bits";
import { authorName, deleteBooks, setState, toggleInList, useStore, type Book } from "@/lib/store";
import { FIELDS, searchBooks, type Criterion, type FieldKey } from "@/lib/search";
import { trCompare } from "@/lib/tr";

export const Route = createFileRoute("/kitaplar")({
  validateSearch: (s: Record<string, unknown>) => ({ q: typeof s['q'] === "string" ? (s['q'] as string) : undefined }) as { q?: string | undefined },
  head: () => ({
    meta: [
      { title: "Kitaplarım – KÜTÜP" },
      { name: "description", content: "Tüm kitaplarınızı arayın, sıralayın ve filtreleyin." },
      { property: "og:title", content: "Kitaplarım – KÜTÜP" },
      { property: "og:description", content: "Tüm kitaplarınızı arayın, sıralayın ve filtreleyin." },
    ],
  }),
  component: Books,
});

const SORTS: Record<string, [string, (a: Book, b: Book) => number]> = {
  title: ["Kitap adı A–Z", (a, b) => trCompare(a.title, b.title)],
  titleDesc: ["Kitap adı Z–A", (a, b) => trCompare(b.title, a.title)],
  author: ["Yazar soyadı", (a, b) => trCompare(a.lastName, b.lastName) || trCompare(a.firstName, b.firstName)],
  year: ["Basım yılı (yeni)", (a, b) => (b.year ?? 0) - (a.year ?? 0)],
  yearAsc: ["Basım yılı (eski)", (a, b) => (a.year ?? 9999) - (b.year ?? 9999)],
  added: ["Son eklenen", (a, b) => b.createdAt - a.createdAt],
};

function Books() {
  const { q: initialQ } = Route.useSearch();
  const books = useStore((s) => s.books);
  const lists = useStore((s) => s.lists);
  const view = useStore((s) => s.settings.view);
  const recent = useStore((s) => s.recentSearches);
  const [q, setQ] = useState(initialQ ?? "");
  const [adv, setAdv] = useState(false);
  const [crit, setCrit] = useState<Criterion[]>([{ field: "lastName", value: "" }]);
  const [sort, setSort] = useState("title");
  const [readFilter, setReadFilter] = useState("all");
  const [sel, setSel] = useState<Set<string> | null>(null);
  const [confirmDel, setConfirmDel] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const nav = useNavigate();

  const results = useMemo(() => {
    let r = searchBooks(books, q, adv ? crit : []);
    if (readFilter !== "all") r = r.filter((b) => b.read === (readFilter === "read"));
    return [...r].sort(SORTS[sort]![1]);
  }, [books, q, adv, crit, sort, readFilter]);

  const saveRecent = () => {
    const t = q.trim();
    if (t) setState((s) => ({ ...s, recentSearches: [t, ...s.recentSearches.filter((x) => x !== t)].slice(0, 8) }));
  };
  const toggle = (id: string) => setSel((p) => { const n = new Set(p ?? []); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const press = (id: string) => ({
    onPointerDown: () => { timer.current = setTimeout(() => { setSel((p) => new Set([...(p ?? []), id])); navigator.vibrate?.(30); timer.current = undefined; }, 500); },
    onPointerUp: () => clearTimeout(timer.current),
    onPointerLeave: () => clearTimeout(timer.current),
    onContextMenu: (e: React.MouseEvent) => e.preventDefault(),
    onClick: (e: React.MouseEvent) => {
      if (sel) { e.preventDefault(); toggle(id); }
      else if (!timer.current && sel === null) { /* normal tıklama */ }
    },
  });
  const highlightQ = q || crit.map((c) => c.value).find(Boolean);

  return (
    <div>
      <PageHeader title={sel ? `${sel.size} seçili` : "Kitaplarım"}>
        {sel ? (
          <>
            <Button size="icon" variant="ghost" aria-label="Tümünü seç" onClick={() => setSel(new Set(results.map((b) => b.id)))}><CheckSquare /></Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild><Button size="icon" variant="ghost" aria-label="Listeye ekle" disabled={!sel.size}><ListPlus /></Button></DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuLabel>Listeye ekle</DropdownMenuLabel>
                {lists.map((l) => <DropdownMenuItem key={l.id} onClick={() => { toggleInList(l.id, [...sel], true); toast.success(`${sel.size} kitap “${l.name}” listesine eklendi.`); setSel(null); }}>{l.name}</DropdownMenuItem>)}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button size="icon" variant="ghost" aria-label="Sil" disabled={!sel.size} onClick={() => setConfirmDel(true)}><Trash2 /></Button>
            <Button size="icon" variant="ghost" aria-label="Seçimi kapat" onClick={() => setSel(null)}><X /></Button>
          </>
        ) : (
          <>
            <Button size="icon" variant="ghost" aria-label="Seçim modu" onClick={() => setSel(new Set())}><CheckSquare /></Button>
            <Button size="icon" variant="ghost" aria-label="Görünüm" onClick={() => setState((s) => ({ ...s, settings: { ...s.settings, view: view === "card" ? "list" : "card" } }))}>{view === "card" ? <List /> : <Grid2x2 />}</Button>
            <Button size="icon" aria-label="Kitap ekle" onClick={() => openBookForm()}><Plus /></Button>
          </>
        )}
      </PageHeader>

      <div className="space-y-3 p-4">
        <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); saveRecent(); }}>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <Input value={q} onBlur={saveRecent} onChange={(e) => setQ(e.target.value)} placeholder="Tüm alanlarda ara" className="h-11 pl-10" />
          </div>
          <Button type="button" size="icon" variant={adv ? "default" : "outline"} className="h-11 w-11" aria-label="Gelişmiş arama" onClick={() => setAdv(!adv)}><SlidersHorizontal /></Button>
        </form>
        {!q && recent.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {recent.map((r) => <button key={r} className="rounded-full bg-secondary px-3 py-1 text-sm" onClick={() => setQ(r)}>{r}</button>)}
            <button className="px-2 text-sm text-muted-foreground" onClick={() => setState((s) => ({ ...s, recentSearches: [] }))}>Temizle</button>
          </div>
        )}
        {adv && (
          <div className="space-y-2 rounded-xl border bg-card p-3">
            <p className="text-sm font-semibold">Alan bazlı arama (tüm koşullar sağlanmalı)</p>
            {crit.map((c, i) => (
              <div key={i} className="flex gap-2">
                <Select value={c.field} onValueChange={(v) => setCrit(crit.map((x, k) => (k === i ? { ...x, field: v as FieldKey } : x)))}>
                  <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                  <SelectContent>{FIELDS.map((f) => <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>)}</SelectContent>
                </Select>
                <Input value={c.value} placeholder="Değer" onChange={(e) => setCrit(crit.map((x, k) => (k === i ? { ...x, value: e.target.value } : x)))} />
                <Button size="icon" variant="ghost" aria-label="Koşulu kaldır" onClick={() => setCrit(crit.length > 1 ? crit.filter((_, k) => k !== i) : [{ field: "lastName", value: "" }])}><X /></Button>
              </div>
            ))}
            <Button size="sm" variant="secondary" onClick={() => setCrit([...crit, { field: "genre", value: "" }])}>+ Koşul ekle</Button>
          </div>
        )}
        <div className="flex gap-2">
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="flex-1"><SelectValue /></SelectTrigger>
            <SelectContent>{Object.entries(SORTS).map(([k, [l]]) => <SelectItem key={k} value={k}>{l}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={readFilter} onValueChange={setReadFilter}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="all">Tümü</SelectItem><SelectItem value="read">Okunanlar</SelectItem><SelectItem value="unread">Okunmayanlar</SelectItem></SelectContent>
          </Select>
        </div>
        <p className="text-sm text-muted-foreground">{results.length} kitap {sel === null && books.length > 0 && "· Seçmek için uzun basın"}</p>

        {results.length === 0 ? (
          books.length === 0 ? (
            <Empty title="Henüz kitap yok" text="İlk kitabını ekleyerek kütüphaneni oluşturmaya başla." action={<Button onClick={() => openBookForm()}>Kitap Ekle</Button>} />
          ) : (
            <Empty title="Sonuç bulunamadı" text="Farklı bir kelime deneyin, yazımı kontrol edin veya gelişmiş aramadaki koşulları azaltın." action={<Button variant="secondary" onClick={() => { setQ(""); setCrit([{ field: "lastName", value: "" }]); }}>Aramayı temizle</Button>} />
          )
        ) : view === "list" ? (
          <ul className="divide-y rounded-xl border bg-card">
            {results.map((b) => (
              <li key={b.id} className="select-none">
                <Link to="/kitap/$id" params={{ id: b.id }} className="flex items-center gap-2 p-3" {...press(b.id)}>
                  {sel && <Checkbox checked={sel.has(b.id)} />}
                  <div className="flex-1"><BookRow book={b} q={highlightQ} /></div>
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {results.map((b) => (
              <li key={b.id} className="select-none">
                <Link to="/kitap/$id" params={{ id: b.id }} className={`relative block rounded-xl border bg-card p-2 ${sel?.has(b.id) ? "ring-2 ring-ring" : ""}`} {...press(b.id)}>
                  {sel && <Checkbox checked={sel.has(b.id)} className="absolute right-3 top-3 z-10 bg-card" />}
                  <Cover book={b} className="aspect-[2/3] w-full" />
                  <div className="mt-2 line-clamp-2 text-sm font-semibold"><Hl text={b.title} q={highlightQ} /></div>
                  <div className="truncate text-xs text-muted-foreground"><Hl text={authorName(b)} q={highlightQ} /></div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>

      <AlertDialog open={confirmDel} onOpenChange={setConfirmDel}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>{sel?.size} kitap silinsin mi?</AlertDialogTitle><AlertDialogDescription>Bu işlem geri alınamaz. Kitaplar tüm listelerden ve okuma planlarından da çıkarılır.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Vazgeç</AlertDialogCancel><AlertDialogAction className="bg-destructive text-destructive-foreground" onClick={() => { deleteBooks([...(sel ?? [])]); toast.success("Kitaplar silindi."); setSel(null); nav({ to: "/kitaplar", search: {} }); }}>Sil</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
