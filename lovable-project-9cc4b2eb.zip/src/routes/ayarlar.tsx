import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Download, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Logo, PageHeader } from "@/components/kutup/ui-bits";
import { getState, loadSample, replaceState, resetAll, setState, useStore, type Settings, type State } from "@/lib/store";
import { download, fromCSV, toCSV, toXLS } from "@/lib/export";

export const Route = createFileRoute("/ayarlar")({
  head: () => ({
    meta: [
      { title: "Ayarlar – KÜTÜP" },
      { name: "description", content: "Tema, yazı boyutu, bildirimler, yedekleme ve içe/dışa aktarma." },
      { property: "og:title", content: "Ayarlar – KÜTÜP" },
      { property: "og:description", content: "Tema, bildirimler ve yedekleme ayarları." },
    ],
  }),
  component: SettingsPage,
});

function pick(accept: string, cb: (text: string) => void) {
  const i = document.createElement("input");
  i.type = "file";
  i.accept = accept;
  i.onchange = () => i.files?.[0]?.text().then(cb);
  i.click();
}

function SettingsPage() {
  const s = useStore((x) => x.settings);
  const count = useStore((x) => x.books.length);
  const [perm, setPerm] = useState<string>("default");
  useEffect(() => setPerm(typeof Notification === "undefined" ? "unsupported" : Notification.permission), []);
  const up = (p: Partial<Settings>) => setState((st) => ({ ...st, settings: { ...st.settings, ...p } }));
  const stamp = new Date().toISOString().slice(0, 10);

  return (
    <div>
      <PageHeader title="Ayarlar" />
      <div className="space-y-6 p-4">
        <Card title="Görünüm">
          <Label>Tema</Label>
          <div className="grid grid-cols-3 gap-2">
            {(["light", "dark", "system"] as const).map((t) => (
              <Button key={t} variant={s.theme === t ? "default" : "secondary"} onClick={() => up({ theme: t })}>{{ light: "Açık", dark: "Koyu", system: "Sistem" }[t]}</Button>
            ))}
          </div>
          <Label>Yazı boyutu: %{Math.round(s.fontScale * 100)}</Label>
          <Slider min={0.85} max={1.3} step={0.05} value={[s.fontScale]} onValueChange={([v]) => up({ fontScale: v ?? 1 })} />
        </Card>

        <Card title="Bildirimler">
          {perm === "granted" ? <p className="text-sm text-muted-foreground">Bildirim izni verildi.</p>
            : perm === "denied" ? <p className="text-sm text-muted-foreground">Bildirimler engellendi. Açmak için tarayıcı/telefon ayarlarından bu site için bildirim iznini “İzin ver” yapın. Bu sırada uygulama içi hatırlatmalar çalışmaya devam eder.</p>
            : perm === "unsupported" ? <p className="text-sm text-muted-foreground">Bu tarayıcı bildirimleri desteklemiyor; uygulama içi hatırlatmalar kullanılır.</p>
            : <Button variant="secondary" onClick={() => Notification.requestPermission().then(setPerm)}>Bildirimlere izin ver</Button>}
          <p className="text-xs text-muted-foreground">Not: Hatırlatmalar KÜTÜP açıkken (arka planda sekme olarak da) çalışır.</p>
          <Row label="Tüm hatırlatmaları duraklat"><Switch checked={s.remindersPaused} onCheckedChange={(v) => up({ remindersPaused: v })} /></Row>
          <Label>Sessiz saatler</Label>
          <div className="flex items-center gap-2"><Input type="time" value={s.quietStart} onChange={(e) => up({ quietStart: e.target.value })} /><span>–</span><Input type="time" value={s.quietEnd} onChange={(e) => up({ quietEnd: e.target.value })} /></div>
        </Card>

        <Card title="Yedekleme ve aktarma">
          <p className="text-sm text-muted-foreground">Verileriniz yalnızca bu cihazda saklanır. Düzenli yedek almanızı öneririz. ({count} kitap)</p>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="secondary" onClick={() => download(`kutup-yedek-${stamp}.json`, JSON.stringify(getState(), null, 2), "application/json")}><Download className="mr-1 h-4 w-4" />JSON yedek</Button>
            <Button variant="secondary" onClick={() => pick("application/json,.json", (t) => {
              try { const d = JSON.parse(t) as State; if (!Array.isArray(d.books)) throw 0; if (confirm(`Yedekteki ${d.books.length} kitap geri yüklensin mi? Mevcut verilerin yerini alır.`)) { replaceState(d); toast.success("Yedek geri yüklendi."); } }
              catch { toast.error("Geçersiz yedek dosyası."); }
            })}><Upload className="mr-1 h-4 w-4" />Geri yükle</Button>
            <Button variant="secondary" onClick={() => download(`kutup-${stamp}.csv`, toCSV(getState().books), "text/csv;charset=utf-8")}><Download className="mr-1 h-4 w-4" />CSV dışa</Button>
            <Button variant="secondary" onClick={() => pick(".csv,text/csv", (t) => {
              const b = fromCSV(t);
              if (!b.length) { toast.error("CSV’de uygun kitap bulunamadı. Başlıklar: Yazar Adı; Yazar Soyadı; Kitap Adı …"); return; }
              setState((st) => ({ ...st, books: [...b, ...st.books] }));
              toast.success(`${b.length} kitap içe aktarıldı.`);
            })}><Upload className="mr-1 h-4 w-4" />CSV içe</Button>
            <Button variant="secondary" className="col-span-2" onClick={() => download(`kutup-${stamp}.xls`, toXLS(getState().books), "application/vnd.ms-excel")}><Download className="mr-1 h-4 w-4" />Excel olarak dışa aktar</Button>
          </div>
        </Card>

        <Card title="Veriler">
          <div className="grid grid-cols-2 gap-2">
            <Button variant="secondary" onClick={() => { loadSample(); toast.success("10 örnek kitap eklendi."); }}>Örnek verileri yükle</Button>
            <Button variant="destructive" onClick={() => { if (confirm("Tüm kitaplar, listeler ve planlar silinecek. Emin misiniz?")) { resetAll(); toast.success("Veriler sıfırlandı."); } }}>Tümünü sıfırla</Button>
          </div>
          <Button variant="ghost" onClick={() => up({ onboarded: false })}>Tanıtımı yeniden göster</Button>
        </Card>

        <Card title="Hakkında">
          <Logo className="text-2xl text-primary" />
          <p className="text-sm text-muted-foreground">Kütüphane Düzenleme Uygulaması · Sürüm 1.0<br />Kitaplarınızı kataloglayın, arayın, listeleyin ve okuma planı yapın. Ana ekrana eklemek için tarayıcı menüsünden “Ana ekrana ekle”yi seçin.</p>
        </Card>
      </div>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="space-y-3 rounded-xl border bg-card p-4"><h2 className="text-lg font-bold">{title}</h2>{children}</section>;
}
function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="flex min-h-11 items-center justify-between"><Label>{label}</Label>{children}</div>;
}
