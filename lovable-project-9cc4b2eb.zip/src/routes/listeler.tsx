import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import * as Icons from "lucide-react";
import { ChevronDown, ChevronUp, ChevronRight, FileText, Pencil, Plus, Share2, Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { BookRow, Empty, PageHeader } from "@/components/kutup/ui-bits";
import { authorName, setState, toggleInList, uid, useStore, type Book, type UserList } from "@/lib/store";
import { norm, trCompare } from "@/lib/tr";
import { listText, printPDF } from "@/lib/export";

export const Route = createFileRoute("/listeler")({
  head: () => ({
    meta: [
      { title: "Listeler – KÜTÜP" },
      { name: "description", content: "Yazar, yayınevi, tür ve yıla göre otomatik listeler ile kendi listeleriniz." },
      { property: "og:title", content: "Listeler – KÜTÜP" },
      { property: "og:description", content: "Otomatik ve kişisel kitap listeleri." },
    ],
  }),
  component: Lists,
});

type Group = { key: string; label: string; books: Book[]; children?: Group[] };
const AUTO = {
  author: "Yazarlar",
  title: "Kitap adları",
  publisher: "Yayınevleri",
  genre: "Tür / alt tür",
  subject: "Konular",
  year: "Basım yılı",
} as const;
type AutoKey = keyof typeof AUTO;

function group(books: Book[], by: (b: Book) => string, label?: (b: Book) => string): Group[] {
  const m = new Map<string, Group>();
  for (const b of books) {
    const k = by(b) || "—";
    if (!m.has(k)) m.set(k, { key: k, label: label?.(b) || k, books: [] });
    m.get(k)!.books.push(b);
  }
  return [...m.values()];
}

function buildGroups(books: Book[], kind: AutoKey): Group[] {
  switch (kind) {
    case "author":
      return group(books, (b) => `${b.lastName}, ${b.firstName}`, (b) => `${b.lastName}, ${b.firstName}`);
    case "title":
      return group(books, (b) => b.title.charAt(0).toLocaleUpperCase("tr"));
    case "publisher":
      return group(books, (b) => b.publisher || "Yayınevi belirtilmemiş");
    case "genre":
      return group(books, (b) => b.genre || "Tür belirtilmemiş").map((g) => ({ ...g, children: group(g.books, (b) => b.subgenre || "Alt tür yok") }));
    case "subject": {
      // Konu metnindeki anahtar kelimelere göre: alt türü konu etiketi olarak kullan, yoksa ilk kelimeler
      return group(books, (b) => b.subgenre || (b.subject.split(/[,.]/)[0] ?? "").trim().slice(0, 40) || "Konu belirtilmemiş");
    }
    case "year":
      return group(books, (b) => (b.year ? String(b.year) : "Yıl belirtilmemiş"));
  }
}

const COLORS = ["oklch(0.55 0.12 250)", "oklch(0.6 0.18 25)", "oklch(0.7 0.13 75)", "oklch(0.55 0.12 150)", "oklch(0.5 0.12 300)", "oklch(0.45 0.05 50)"];
const ICONS = ["BookMarked", "Heart", "Star", "Handshake", "Sofa", "Bookmark", "Flame", "Gift"];
function LIcon({ name, className }: { name: string; className?: string | undefined }) {
  const C = (Icons as unknown as Record<string, React.ComponentType<{ className?: string | undefined }>>)[name] ?? Icons.Bookmark;
  return <C className={className} />;
}

function Lists() {
  return (
    <div>
      <PageHeader title="Listeler" />
      <Tabs defaultValue="auto" className="p-4">
        <TabsList className="grid h-11 w-full grid-cols-2"><TabsTrigger value="auto">Otomatik</TabsTrigger><TabsTrigger value="mine">Listelerim</TabsTrigger></TabsList>
        <TabsContent value="auto"><AutoLists /></TabsContent>
        <TabsContent value="mine"><MyLists /></TabsContent>
      </Tabs>
    </div>
  );
}

function AutoLists() {
  const books = useStore((s) => s.books);
  const [kind, setKind] = useState<AutoKey>("author");
  const [dir, setDir] = useState<"az" | "za" | "count">("az");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<Set<string>>(new Set());
  const groups = useMemo(() => {
    const nq = norm(q);
    let g = buildGroups(books, kind).map((x) => ({ ...x, books: [...x.books].sort((a, b) => kind === "year" ? trCompare(a.title, b.title) : trCompare(a.title, b.title)) }));
    if (nq) g = g.filter((x) => norm(x.label).includes(nq) || x.books.some((b) => norm(b.title + " " + authorName(b)).includes(nq)));
    const cmp = kind === "year" ? (a: Group, b: Group) => (Number(a.key) || 99999) - (Number(b.key) || 99999) : (a: Group, b: Group) => trCompare(a.label, b.label);
    g.sort(dir === "count" ? (a, b) => b.books.length - a.books.length : dir === "az" ? cmp : (a, b) => cmp(b, a));
    return g;
  }, [books, kind, dir, q]);
  const tog = (k: string) => setOpen((p) => { const n = new Set(p); n.has(k) ? n.delete(k) : n.add(k); return n; });

  if (!books.length) return <Empty title="Listeler boş" text="Kitap ekledikçe yazar, yayınevi, tür ve yıla göre listeler kendiliğinden oluşur." />;
  return (
    <div className="space-y-3 pt-2">
      <div className="flex gap-2 overflow-x-auto pb-1">
        {(Object.keys(AUTO) as AutoKey[]).map((k) => (
          <button key={k} onClick={() => setKind(k)} className={`shrink-0 rounded-full px-4 py-2 text-sm ${kind === k ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{AUTO[k]}</button>
        ))}
      </div>
      <div className="flex gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Liste içinde ara" />
        <Select value={dir} onValueChange={(v) => setDir(v as typeof dir)}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="az">{kind === "year" ? "Eski → Yeni" : "A–Z"}</SelectItem><SelectItem value="za">{kind === "year" ? "Yeni → Eski" : "Z–A"}</SelectItem><SelectItem value="count">Kitap sayısı</SelectItem></SelectContent>
        </Select>
      </div>
      <p className="text-sm text-muted-foreground">{groups.length} grup · {books.length} kitap</p>
      <ul className="divide-y rounded-xl border bg-card">
        {groups.map((g) => (
          <li key={g.key}>
            <button className="flex min-h-12 w-full items-center justify-between px-3 text-left" onClick={() => tog(g.key)}>
              <span className="font-semibold">{g.label}</span>
              <span className="flex items-center gap-2 text-sm text-muted-foreground">{g.books.length} kitap <ChevronRight className={`h-4 w-4 transition ${open.has(g.key) ? "rotate-90" : ""}`} /></span>
            </button>
            {open.has(g.key) && (
              <div className="bg-muted/40 px-3 pb-2">
                {g.children ? (
                  g.children.sort((a, b) => trCompare(a.label, b.label)).map((c) => (
                    <div key={c.key}>
                      <button className="flex min-h-10 w-full items-center justify-between pl-3 text-left text-sm" onClick={() => tog(g.key + "/" + c.key)}>
                        <span>{c.label}</span><span className="text-muted-foreground">{c.books.length}</span>
                      </button>
                      {open.has(g.key + "/" + c.key) && <BookLinks books={c.books} />}
                    </div>
                  ))
                ) : (
                  <BookLinks books={g.books} />
                )}
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
function BookLinks({ books }: { books: Book[] }) {
  return <ul className="space-y-1 py-1">{books.map((b) => <li key={b.id}><Link to="/kitap/$id" params={{ id: b.id }} className="block rounded-lg bg-card p-2"><BookRow book={b} /></Link></li>)}</ul>;
}

function MyLists() {
  const lists = useStore((s) => s.lists);
  const books = useStore((s) => s.books);
  const [edit, setEdit] = useState<UserList | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [del, setDel] = useState<UserList | null>(null);
  const current = lists.find((l) => l.id === openId);

  if (current) {
    const items = current.bookIds.map((id) => books.find((b) => b.id === id)).filter(Boolean) as Book[];
    const move = (i: number, d: number) => setState((s) => ({ ...s, lists: s.lists.map((l) => { if (l.id !== current.id) return l; const ids = [...l.bookIds]; const j = i + d; if (j < 0 || j >= ids.length) return l; [ids[i], ids[j]] = [ids[j]!, ids[i]!]; return { ...l, bookIds: ids }; }) }));
    const share = async () => {
      const text = listText(current.name, items);
      if (navigator.share) await navigator.share({ title: current.name, text }).catch(() => {});
      else { await navigator.clipboard.writeText(text); toast.success("Liste panoya kopyalandı."); }
    };
    return (
      <div className="space-y-3 pt-2">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => setOpenId(null)}>← Listeler</Button>
          <h2 className="flex-1 truncate text-xl font-bold">{current.name}</h2>
          <Button size="icon" variant="ghost" aria-label="Metin olarak paylaş" onClick={share}><Share2 /></Button>
          <Button size="icon" variant="ghost" aria-label="PDF olarak dışa aktar" onClick={() => printPDF(current.name, items)}><FileText /></Button>
        </div>
        {items.length === 0 ? <Empty title="Liste boş" text="Kitaplarım sayfasında kitaplara uzun basarak veya kitap detayından bu listeye ekleyebilirsin." /> : (
          <ul className="divide-y rounded-xl border bg-card">
            {items.map((b, i) => (
              <li key={b.id} className="flex items-center gap-1 p-2">
                <Link to="/kitap/$id" params={{ id: b.id }} className="flex-1"><BookRow book={b} /></Link>
                <div className="flex flex-col">
                  <Button size="icon" variant="ghost" className="h-8" aria-label="Yukarı" onClick={() => move(i, -1)}><ChevronUp /></Button>
                  <Button size="icon" variant="ghost" className="h-8" aria-label="Aşağı" onClick={() => move(i, 1)}><ChevronDown /></Button>
                </div>
                <Button size="icon" variant="ghost" aria-label="Listeden çıkar" onClick={() => toggleInList(current.id, [b.id], false)}><X /></Button>
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-3 pt-2">
      <Button className="h-12 w-full" onClick={() => setEdit({ id: "", name: "", color: COLORS[0]!, icon: ICONS[0]!, bookIds: [] })}><Plus className="mr-2" /> Yeni liste</Button>
      <ul className="space-y-2">
        {lists.map((l) => (
          <li key={l.id} className="flex items-center gap-3 rounded-xl border bg-card p-3">
            <button className="flex flex-1 items-center gap-3 text-left" onClick={() => setOpenId(l.id)}>
              <span className="flex h-11 w-11 items-center justify-center rounded-xl text-primary-foreground" style={{ background: l.color }}><LIcon name={l.icon} className="h-5 w-5" /></span>
              <span><span className="block font-semibold">{l.name}</span><span className="text-sm text-muted-foreground">{l.bookIds.length} kitap</span></span>
            </button>
            <Button size="icon" variant="ghost" aria-label="Düzenle" onClick={() => setEdit(l)}><Pencil /></Button>
            <Button size="icon" variant="ghost" aria-label="Sil" onClick={() => setDel(l)}><Trash2 /></Button>
          </li>
        ))}
      </ul>
      <Dialog open={!!edit} onOpenChange={(o) => !o && setEdit(null)}>
        {edit && (
          <DialogContent>
            <DialogHeader><DialogTitle>{edit.id ? "Listeyi düzenle" : "Yeni liste"}</DialogTitle></DialogHeader>
            <Input autoFocus value={edit.name} placeholder="ör. Ödünç verdiklerim" onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            <div className="flex flex-wrap gap-2">{COLORS.map((c) => <button key={c} aria-label="Renk" className={`h-9 w-9 rounded-full ${edit.color === c ? "ring-2 ring-ring ring-offset-2" : ""}`} style={{ background: c }} onClick={() => setEdit({ ...edit, color: c })} />)}</div>
            <div className="flex flex-wrap gap-2">{ICONS.map((i) => <button key={i} aria-label={i} className={`flex h-10 w-10 items-center justify-center rounded-lg border ${edit.icon === i ? "bg-primary text-primary-foreground" : ""}`} onClick={() => setEdit({ ...edit, icon: i })}><LIcon name={i} className="h-5 w-5" /></button>)}</div>
            <DialogFooter>
              <Button disabled={!edit.name.trim()} onClick={() => {
                const l = { ...edit, name: edit.name.trim() };
                setState((s) => ({ ...s, lists: l.id ? s.lists.map((x) => (x.id === l.id ? l : x)) : [...s.lists, { ...l, id: uid() }] }));
                setEdit(null);
                toast.success("Liste kaydedildi.");
              }}>Kaydet</Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
      <AlertDialog open={!!del} onOpenChange={(o) => !o && setDel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>“{del?.name}” silinsin mi?</AlertDialogTitle><AlertDialogDescription>Yalnızca liste silinir; kitaplar kütüphanende kalır.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Vazgeç</AlertDialogCancel><AlertDialogAction onClick={() => { setState((s) => ({ ...s, lists: s.lists.filter((x) => x.id !== del?.id) })); setDel(null); }}>Sil</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
