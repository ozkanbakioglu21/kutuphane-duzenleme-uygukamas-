import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Bell, BookPlus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getState, loadStore, markSession, occurrencesOn, setState, useStore, ymd } from "@/lib/store";
import icon from "@/assets/kutup-icon.png";
import { Logo } from "./ui-bits";

/** Tema, yazı boyutu ve yükleme */
export function useAppEffects() {
  const settings = useStore((s) => s.settings);
  useEffect(() => { loadStore(); }, []);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () =>
      document.documentElement.classList.toggle("dark", settings.theme === "dark" || (settings.theme === "system" && mq.matches));
    apply();
    mq.addEventListener("change", apply);
    document.documentElement.style.fontSize = `${settings.fontScale * 100}%`;
    return () => mq.removeEventListener("change", apply);
  }, [settings.theme, settings.fontScale]);
}

export function Splash() {
  const [show, setShow] = useState(true);
  useEffect(() => { const t = setTimeout(() => setShow(false), 900); return () => clearTimeout(t); }, []);
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-4 bg-background animate-out fade-out duration-500 fill-mode-forwards" style={{ animationDelay: "600ms" }}>
      <img src={icon} alt="KÜTÜP" width={1024} height={1024} className="h-28 w-28 rounded-3xl shadow-lg" />
      <p className="text-sm text-muted-foreground">Kütüphane Düzenleme Uygulaması</p>
    </div>
  );
}

const STEPS = [
  { icon: BookPlus, title: "Kitaplarını kataloğla", text: "Evindeki ve işyerindeki kitapları saniyeler içinde ekle. Yazar, yayınevi ve türe göre listeler kendiliğinden oluşur." },
  { icon: Search, title: "Anında bul", text: "Tek arama çubuğu tüm alanlarda arar. Türkçe karakter ve büyük/küçük harf farkı sorun değil." },
  { icon: Bell, title: "Okuma planı yap", text: "Hangi kitabı hangi gün ve saatte okuyacağını planla. İstersen sana hatırlatalım." },
];

export function Onboarding() {
  const onboarded = useStore((s) => s.settings.onboarded);
  const [hydrated, setHydrated] = useState(false);
  const [i, setI] = useState(0);
  useEffect(() => { loadStore(); setHydrated(true); }, []);
  if (!hydrated || onboarded) return null;
  const finish = () => setState((s) => ({ ...s, settings: { ...s.settings, onboarded: true } }));
  const S = STEPS[i]!;
  return (
    <div className="fixed inset-0 z-[90] flex flex-col bg-background">
      <div className="flex items-center justify-between p-5">
        <Logo className="text-2xl text-primary" />
        <button className="p-2 text-sm text-muted-foreground" onClick={finish}>Atla</button>
      </div>
      <div className="flex flex-1 flex-col items-center justify-center gap-6 px-8 text-center">
        <div className="flex h-28 w-28 items-center justify-center rounded-full bg-secondary"><S.icon className="h-14 w-14 text-primary" /></div>
        <h2 className="text-3xl font-bold">{S.title}</h2>
        <p className="max-w-sm text-muted-foreground">{S.text}</p>
        {i === 2 && typeof Notification !== "undefined" && Notification.permission === "default" && (
          <div className="rounded-xl border bg-card p-4 text-sm">
            <p className="mb-3">Okuma saatin geldiğinde bildirim göndermemize izin verir misin? İzin vermesen de uygulama sorunsuz çalışır.</p>
            <Button variant="secondary" onClick={() => Notification.requestPermission().then((p) => toast(p === "granted" ? "Bildirimler açıldı." : "Bildirim izni verilmedi. Daha sonra Ayarlar'dan açabilirsin."))}>Bildirimlere izin ver</Button>
          </div>
        )}
      </div>
      <div className="flex items-center justify-between gap-4 p-6 pb-10">
        <div className="flex gap-2">{STEPS.map((_, k) => <span key={k} className={`h-2 rounded-full transition-all ${k === i ? "w-6 bg-primary" : "w-2 bg-border"}`} />)}</div>
        <Button className="h-12 px-8" onClick={() => (i < 2 ? setI(i + 1) : finish())}>{i < 2 ? "İleri" : "Başla"}</Button>
      </div>
    </div>
  );
}

function beep() {
  try {
    const ctx = new AudioContext();
    [0, 0.4, 0.8].forEach((t) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 880;
      g.gain.setValueAtTime(0.3, ctx.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.3);
      o.connect(g).connect(ctx.destination);
      o.start(ctx.currentTime + t);
      o.stop(ctx.currentTime + t + 0.3);
    });
  } catch { /* ses desteklenmiyor */ }
}
const inQuiet = (now: string, a: string, b: string) => (a <= b ? now >= a && now < b : now >= a || now < b);

/** Uygulama açıkken planlanan saatte hatırlatır. */
export function ReminderEngine() {
  const fired = useRef(new Set<string>());
  const snoozed = useRef<{ key: string; at: number; fire: () => void }[]>([]);
  useEffect(() => {
    const tick = () => {
      const s = getState();
      const now = new Date();
      const hm = now.toTimeString().slice(0, 5);
      snoozed.current = snoozed.current.filter((x) => (x.at <= now.getTime() ? (x.fire(), false) : true));
      if (s.settings.remindersPaused || inQuiet(hm, s.settings.quietStart, s.settings.quietEnd)) return;
      for (const o of occurrencesOn(s, now)) {
        const key = `${o.plan.id}-${ymd(now)}`;
        if (o.plan.reminder === "none" || o.session || o.time !== hm || fired.current.has(key)) continue;
        fired.current.add(key);
        const fire = () => {
          const st = getState();
          const book = st.books.find((b) => b.id === o.plan.bookIds[0]);
          if (!book) return;
          const goal = o.plan.goalType === "minutes" ? `${o.plan.goalValue} dk` : `${o.plan.goalValue} sayfa`;
          const msg = `Bugün '${book.title}' okuma zamanı: ${goal}`;
          if (o.plan.reminder === "alarm") beep();
          if (typeof Notification !== "undefined" && Notification.permission === "granted") {
            try { new Notification("KÜTÜP", { body: msg, icon: "/icon-192.png", tag: key }); } catch { /* mobil tarayıcı */ }
          }
          toast(msg, {
            duration: 60000,
            action: { label: "Başla", onClick: () => { window.location.href = "/cizelge"; } },
            cancel: { label: "Ertele (10 dk)", onClick: () => snoozed.current.push({ key, at: Date.now() + 600000, fire }) },
            description: (
              <button className="underline" onClick={() => { markSession(o.plan.id, book.id, ymd(new Date()), "skipped"); toast("Bugünkü oturum atlandı."); }}>Bugün atla</button>
            ),
          });
        };
        fire();
      }
    };
    tick();
    const id = setInterval(tick, 20000);
    return () => clearInterval(id);
  }, []);
  return null;
}
