import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Camera, AlertTriangle } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { GENRES, SUBGENRES, getState, isDuplicate, saveBook, useStore, type Book } from "@/lib/store";
import { findSimilar, trCompare } from "@/lib/tr";
import { closeBookForm, useBookForm } from "./ui-bits";

type Draft = Omit<Book, "id" | "createdAt">;
const blank = (): Draft => ({
  firstName: "", lastName: "", title: "", publisher: "", genre: "", subgenre: "", subject: "",
  year: undefined, pages: undefined, cover: undefined, shelf: "", note: "", read: false, readPages: 0,
});

async function resize(file: File): Promise<string> {
  const url = URL.createObjectURL(file);
  const img = new Image();
  img.src = url;
  await img.decode();
  const scale = Math.min(1, 360 / img.width);
  const c = document.createElement("canvas");
  c.width = img.width * scale;
  c.height = img.height * scale;
  c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
  URL.revokeObjectURL(url);
  return c.toDataURL("image/jpeg", 0.75);
}

export function BookForm() {
  const { open, editId } = useBookForm();
  const books = useStore((s) => s.books);
  const custom = useStore((s) => s.customSubgenres);
  const [d, setD] = useState<Draft>(blank);
  const [yearText, setYearText] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [last, setLast] = useState<Draft | null>(null);
  const firstRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    const b = editId ? getState().books.find((x) => x.id === editId) : undefined;
    const next = b ? { ...b } : blank();
    setD(next);
    setYearText(next.year ? String(next.year) : "");
    setErrors({});
  }, [open, editId]);

  const uniq = (k: keyof Draft) => Array.from(new Set(books.map((b) => String(b[k] ?? "")).filter(Boolean))).sort(trCompare);
  const publishers = useMemo(() => uniq("publisher"), [books]);
  const genres = useMemo(() => Array.from(new Set([...GENRES, ...uniq("genre")])), [books]);
  const subs = useMemo(
    () => Array.from(new Set([...(SUBGENRES[d.genre] ?? []), ...(custom[d.genre] ?? []), ...books.filter((b) => b.genre === d.genre).map((b) => b.subgenre).filter(Boolean)])),
    [d.genre, books, custom],
  );
  const pubSimilar = d.publisher ? findSimilar(d.publisher, publishers) : null;
  const genreSimilar = d.genre ? findSimilar(d.genre, genres) : null;

  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => setD((p) => ({ ...p, [k]: v }));

  function validate() {
    const e: Record<string, string> = {};
    if (!d.firstName.trim()) e['firstName'] = "Yazar adı zorunludur.";
    if (!d.lastName.trim()) e['lastName'] = "Yazar soyadı zorunludur.";
    if (!d.title.trim()) e['title'] = "Kitap adı zorunludur.";
    if (yearText && !/^\d{4}$/.test(yearText)) e['year'] = "Basım yılı 4 haneli olmalıdır (ör. 2019).";
    else if (yearText && Number(yearText) > new Date().getFullYear() + 1) e['year'] = "Basım yılı gelecekte olamaz.";
    if (d.pages !== undefined && (d.pages < 1 || !Number.isInteger(d.pages))) e['pages'] = "Sayfa sayısı pozitif tam sayı olmalıdır.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function submit(again: boolean) {
    if (!validate()) return;
    const data: Draft = {
      ...d,
      firstName: d.firstName.trim(), lastName: d.lastName.trim(), title: d.title.trim(),
      publisher: d.publisher.trim(), genre: d.genre.trim(), subgenre: d.subgenre.trim(),
      year: yearText ? Number(yearText) : undefined,
    };
    const dup = isDuplicate(data, editId);
    if (dup && !confirm("Bu kitap (yazar, ad, yayınevi ve yıl) kütüphanenizde zaten var. Yine de eklensin mi?")) return;
    saveBook(data, editId);
    toast.success(editId ? "Kitap güncellendi." : "Kitap eklendi.");
    setLast(data);
    if (again) {
      setD(blank());
      setYearText("");
      firstRef.current?.focus();
    } else closeBookForm();
  }

  function copyLast() {
    if (!last) return;
    setD((p) => ({ ...p, firstName: last.firstName, lastName: last.lastName, publisher: last.publisher, genre: last.genre, subgenre: last.subgenre }));
  }

  const err = (k: string) => errors[k] && <p className="text-sm text-destructive">{errors[k]}</p>;
  const warn = (s: string | null) =>
    s && (
      <p className="flex items-center gap-1 text-sm text-gold">
        <AlertTriangle className="h-4 w-4" /> Benzer kayıt var: “{s}”.
      </p>
    );

  return (
    <Sheet open={open} onOpenChange={(o) => !o && closeBookForm()}>
      <SheetContent side="bottom" className="mx-auto h-[92dvh] max-w-2xl overflow-y-auto rounded-t-2xl">
        <SheetHeader>
          <SheetTitle className="font-display text-2xl">{editId ? "Kitabı Düzenle" : "Kitap Ekle"}</SheetTitle>
        </SheetHeader>
        <datalist id="dl-pub">{publishers.map((p) => <option key={p} value={p} />)}</datalist>
        <datalist id="dl-genre">{genres.map((p) => <option key={p} value={p} />)}</datalist>
        <datalist id="dl-sub">{subs.map((p) => <option key={p} value={p} />)}</datalist>
        <form className="space-y-4 px-4 pb-8" onSubmit={(e) => { e.preventDefault(); submit(false); }}>
          {!editId && last && (
            <Button type="button" variant="secondary" size="sm" onClick={copyLast}>Önceki girişten yazar/yayınevi/tür kopyala</Button>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1"><Label>Yazar Adı *</Label><Input ref={firstRef} value={d.firstName} onChange={(e) => set("firstName", e.target.value)} />{err("firstName")}</div>
            <div className="space-y-1"><Label>Yazar Soyadı *</Label><Input value={d.lastName} onChange={(e) => set("lastName", e.target.value)} />{err("lastName")}</div>
          </div>
          <div className="space-y-1"><Label>Kitap Adı *</Label><Input value={d.title} onChange={(e) => set("title", e.target.value)} />{err("title")}</div>
          <div className="space-y-1"><Label>Yayınevi</Label><Input list="dl-pub" value={d.publisher} onChange={(e) => set("publisher", e.target.value)} />{warn(pubSimilar)}</div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1"><Label>Türü</Label><Input list="dl-genre" value={d.genre} onChange={(e) => set("genre", e.target.value)} />{warn(genreSimilar)}</div>
            <div className="space-y-1"><Label>Alt Türü</Label><Input list="dl-sub" value={d.subgenre} placeholder={d.genre ? "Seçin veya yazın" : "Önce tür seçin"} onChange={(e) => set("subgenre", e.target.value)} /></div>
          </div>
          <div className="space-y-1"><Label>Konusu</Label><Textarea rows={3} value={d.subject} onChange={(e) => set("subject", e.target.value)} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1"><Label>Basım Yılı</Label><Input inputMode="numeric" maxLength={4} value={yearText} onChange={(e) => setYearText(e.target.value.replace(/\D/g, ""))} />{err("year")}</div>
            <div className="space-y-1"><Label>Sayfa Sayısı</Label><Input inputMode="numeric" value={d.pages ?? ""} onChange={(e) => set("pages", e.target.value ? Number(e.target.value.replace(/\D/g, "")) : undefined)} />{err("pages")}</div>
          </div>
          <details className="rounded-lg border p-3">
            <summary className="cursor-pointer font-semibold">Ek bilgiler</summary>
            <div className="mt-3 space-y-3">
              <div className="flex items-center gap-3">
                {d.cover && <img src={d.cover} alt="Kapak" className="h-20 w-14 rounded object-cover" />}
                <Label className="inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-2">
                  <Camera className="h-4 w-4" /> Kapak fotoğrafı
                  <input type="file" accept="image/*" capture="environment" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) set("cover", await resize(f)); }} />
                </Label>
                {d.cover && <Button type="button" variant="ghost" size="sm" onClick={() => set("cover", undefined)}>Kaldır</Button>}
              </div>
              <div className="space-y-1"><Label>Raf / Konum</Label><Input value={d.shelf} onChange={(e) => set("shelf", e.target.value)} placeholder="ör. Salon rafı, 2. sıra" /></div>
              <div className="space-y-1"><Label>Kişisel Not</Label><Textarea rows={2} value={d.note} onChange={(e) => set("note", e.target.value)} /></div>
              <div className="flex items-center justify-between"><Label>Okundu</Label><Switch checked={d.read} onCheckedChange={(v) => set("read", v)} /></div>
            </div>
          </details>
          <div className="sticky bottom-0 flex gap-2 bg-background py-3">
            <Button type="submit" className="h-12 flex-1">Kaydet</Button>
            {!editId && <Button type="button" variant="secondary" className="h-12 flex-1" onClick={() => submit(true)}>Kaydet ve yeni ekle</Button>}
          </div>
        </form>
      </SheetContent>
    </Sheet>
  );
}
