import { useSyncExternalStore, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { BookOpen, Calendar, Home, Library, ListChecks, Settings } from "lucide-react";
import { matchRanges } from "@/lib/tr";
import type { Book } from "@/lib/store";
import { authorName } from "@/lib/store";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex flex-col items-start leading-none ${className}`} aria-label="KÜTÜP">
      <span className="font-display font-black tracking-[0.12em]">KÜTÜP</span>
      <span className="mt-1 h-[3px] w-full rounded-full bg-gold" />
    </span>
  );
}

export function Hl({ text, q }: { text: string; q?: string | undefined }) {
  if (!q || !text) return <>{text}</>;
  const r = matchRanges(text, q);
  if (!r.length) return <>{text}</>;
  const chars = Array.from(text);
  const out: ReactNode[] = [];
  let last = 0;
  r.forEach(([a, b], i) => {
    out.push(chars.slice(last, a).join(""));
    out.push(<mark key={i}>{chars.slice(a, b).join("")}</mark>);
    last = b;
  });
  out.push(chars.slice(last).join(""));
  return <>{out}</>;
}

export function Empty({ title, text, action }: { title: string; text: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-3 px-6 py-12 text-center">
      <svg viewBox="0 0 120 80" className="h-24 w-36 text-muted-foreground/60" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
        <path d="M10 70h100" />
        <rect x="20" y="25" width="12" height="45" rx="2" />
        <rect x="35" y="15" width="14" height="55" rx="2" />
        <rect x="52" y="30" width="10" height="40" rx="2" />
        <path d="M70 70l10-42 12 3-10 39" />
      </svg>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="max-w-xs text-sm text-muted-foreground">{text}</p>
      {action}
    </div>
  );
}

export function Cover({ book, className = "" }: { book: Book; className?: string }) {
  if (book.cover) return <img src={book.cover} alt={book.title} className={`rounded-md object-cover ${className}`} />;
  return (
    <div className={`flex flex-col justify-between rounded-md p-2 text-primary-foreground ${className}`} style={{ background: "var(--gradient-hero)" }}>
      <BookOpen className="h-4 w-4 text-gold" />
      <span className="line-clamp-3 font-display text-[11px] font-semibold leading-tight">{book.title}</span>
    </div>
  );
}

export function BookRow({ book, q, right }: { book: Book; q?: string | undefined; right?: ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <Cover book={book} className="h-16 w-11 shrink-0" />
      <div className="min-w-0 flex-1">
        <div className="truncate font-semibold"><Hl text={book.title} q={q} /></div>
        <div className="truncate text-sm text-muted-foreground"><Hl text={authorName(book)} q={q} /></div>
        <div className="truncate text-xs text-muted-foreground">
          <Hl text={[book.publisher, book.genre, book.subgenre, book.year].filter(Boolean).join(" · ")} q={q} />
        </div>
      </div>
      {right}
    </div>
  );
}

const NAV = [
  { to: "/", label: "Ana Sayfa", icon: Home },
  { to: "/kitaplar", label: "Kitaplarım", icon: Library },
  { to: "/listeler", label: "Listeler", icon: ListChecks },
  { to: "/cizelge", label: "Çizelge", icon: Calendar },
  { to: "/ayarlar", label: "Ayarlar", icon: Settings },
] as const;

export function BottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur">
      <div className="mx-auto grid max-w-2xl grid-cols-5">
        {NAV.map((n) => (
          <Link
            key={n.to}
            to={n.to}
            activeOptions={{ exact: n.to === "/" }}
            className="flex min-h-16 flex-col items-center justify-center gap-1 text-[11px] text-muted-foreground data-[status=active]:font-bold data-[status=active]:text-primary"
          >
            <n.icon className="h-5 w-5" />
            {n.label}
          </Link>
        ))}
      </div>
    </nav>
  );
}

export function PageHeader({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-2 border-b bg-background/95 px-4 py-3 backdrop-blur">
      <h1 className="text-2xl font-bold">{title}</h1>
      <div className="flex items-center gap-1">{children}</div>
    </header>
  );
}

// Kitap formu açma durumu
type FormState = { open: boolean; editId?: string | undefined };
let fs: FormState = { open: false };
const fl = new Set<() => void>();
export function openBookForm(editId?: string) {
  fs = { open: true, editId };
  fl.forEach((l) => l());
}
export function closeBookForm() {
  fs = { open: false };
  fl.forEach((l) => l());
}
export function useBookForm() {
  return useSyncExternalStore((l) => (fl.add(l), () => fl.delete(l)), () => fs, () => fs);
}
